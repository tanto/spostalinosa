Files in this archive have been created from OpenStreetMap data
and are licensed under the Open Database 1.0 License. See 
http://osm.org for details about the project.

This file contains OpenStreetMap data as of  2014-08-04. Every day
a new version of this file will be made available at:

 http://osm-toolserver-italia.wmflabs.org/estratti/ 

This archive is the product of the italian OpenStreetMap community
and of the following wonderful people: 
alain2003,Alexander Roalter,Andrea Borruso,AtonX,Aurimas FiÅ¡eras,Aury88,Axel2009,bdiscoe,bilderhobbit,Cascafico,cibboy,C-in-Berlin,cquest,Damouns,Davide Governale,David Paleino,Davio,dforsi,dgitto,Ernesto Sferlazza,FFes,FvGordon,gbilotta,GeofixFe,GPS-Marco,HBR,Jahr2014,kaitu,KartoGrapHiti,landfahrer,lenux,Lohe,malcolmh,MarcoCarraro,mcheckimport,meet00,mgeiser,Nautic,noebrucy,occam11,Peter14,phobie,Runis,Sal73x,Signor_g,silviop,Thierry_la_Fronde_12,trekker48,vbmanu,venerdi,Verdy_p,vialma,Wankmann,wegavision,woodpeck_repair,ZMWandelaar

For further information: press@openstreetmap.it

